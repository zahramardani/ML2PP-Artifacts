import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, GRU, Dense, Dropout
from tensorflow.keras import regularizers
from keras.callbacks import EarlyStopping
import matplotlib.pyplot as plt
from pathlib import Path
from joblib import dump

USE_MODEL = "lstm"  # lstm gru

FEATURES = ["disch1", "disch2", "disch3"]
TARGET   = "disch2"
SEQ_LEN  = 20
N_STEPS  = 3
CSV_PATH = "./flow_dataset.csv"

MODELS_DIR    = Path(f"models/{USE_MODEL.upper()}"); MODELS_DIR.mkdir(parents=True, exist_ok=True)
MODEL_PATH    = MODELS_DIR / "output.keras"
MANIFEST_PATH = MODELS_DIR / "manifest.pkl"

df = pd.read_csv(CSV_PATH)
df["Date"] = pd.to_datetime(df["Date"], dayfirst=True, errors="coerce")
df = df.dropna(subset=["Date"]).sort_values("Date").drop_duplicates(subset="Date", keep="first")
df = df.set_index("Date").asfreq("D").reset_index()

for c in FEATURES:
    if c in df.columns:
        df[c] = df[c].ffill(limit=10)
df = df.dropna(subset=FEATURES + [TARGET], how="any")

train_size = int(len(df) * 0.8)
train_df, test_df = df.iloc[:train_size], df.iloc[train_size:]

def make_seq(df_part, features, target, seq_len=20, steps=3):
    Xv = df_part[features].values.astype(np.float32)
    yv = df_part[target].values.astype(np.float32)
    X, y = [], []
    limit = len(df_part) - seq_len - steps + 1
    for i in range(limit):
        X.append(Xv[i:i+seq_len, :])
        y.append(yv[i+seq_len:i+seq_len+steps])
    return np.asarray(X, np.float32), np.asarray(y, np.float32)

X_train, y_train = make_seq(train_df, FEATURES, TARGET, SEQ_LEN, N_STEPS)
X_test,  y_test  = make_seq(test_df,  FEATURES, TARGET, SEQ_LEN, N_STEPS)

rnn = LSTM if USE_MODEL == "lstm" else GRU
model = Sequential([
    rnn(90, activation="relu", kernel_regularizer=regularizers.L2(0.01),
        return_sequences=True, input_shape=(SEQ_LEN, len(FEATURES))),
    Dropout(0.2),
    rnn(90, activation="relu", kernel_regularizer=regularizers.L2(0.01),
        return_sequences=False),
    Dropout(0.2),
    Dense(N_STEPS)
])
model.compile(loss="mse", optimizer=tf.keras.optimizers.Adam(1e-3), metrics=["mse","mae"])

early = EarlyStopping(monitor="val_loss", mode="min", patience=10, restore_best_weights=True, verbose=1)
history = model.fit(X_train, y_train, epochs=100, batch_size=32, shuffle=False,
                    validation_data=(X_test, y_test), callbacks=[early], verbose=1)

train = model.evaluate(X_train, y_train, verbose=1)
test  = model.evaluate(X_test,  y_test,  verbose=1)
model.save(MODEL_PATH)

plt.plot(history.history["loss"], label="train_loss")
plt.plot(history.history["val_loss"], label="val_loss")
plt.title(f"Loss ({USE_MODEL.upper()})"); plt.ylabel("MSE"); plt.xlabel("Epoch"); plt.legend()
plt.savefig(MODELS_DIR / f"{USE_MODEL}_loss.png"); plt.close()

y_pred = model.predict(X_test, verbose=1)
pred_ts = test_df["Date"].iloc[SEQ_LEN : SEQ_LEN + len(y_test)].reset_index(drop=True)
results = pd.DataFrame({
    "timestamp": pred_ts,
    "y_true_t0": y_test[:,0], "y_true_t1": y_test[:,1], "y_true_t2": y_test[:,2],
    "y_pred_t0": y_pred[:,0], "y_pred_t1": y_pred[:,1], "y_pred_t2": y_pred[:,2],
})
results.to_csv(MODELS_DIR / f"results_{USE_MODEL}.csv", index=False)

manifest = {
    "model_type": USE_MODEL,
    "lag": SEQ_LEN,
    "steps": N_STEPS,
    "feature_cols": FEATURES,
    "target_col": TARGET,
    "models": {"keras_seq": {"type": "keras", "path": str(MODEL_PATH)}},
    "alert": {"field": TARGET, "op": ">=", "threshold": 150.0}  # edit if needed
}
dump(manifest, MANIFEST_PATH)
print("Saved:", MODEL_PATH, MANIFEST_PATH)
