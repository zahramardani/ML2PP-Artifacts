# sensor.py
import time, random, requests
from datetime import datetime, timezone

def now_ms():
    return int(datetime.now(timezone.utc).timestamp() * 1000)

while True:
    reading = {
        "timestamp": now_ms(),
        "disch1": 100 + random.gauss(0, 5),
        "disch2": 110 + random.gauss(0, 8), 
        "disch3": 95 + random.gauss(0, 6),
    }

    try:
        r = requests.post("http://127.0.0.1:5000/ingest",
                          json={"readings": [reading]},
                          timeout=5)
        print("Sent:", reading, "| status:", r.status_code)
    except Exception as e:
        print("Send error:", e)

    time.sleep(2)
