# analytics.py (universal: works with LR bundle OR Keras manifest)
from flask import Flask, request, jsonify
from collections import defaultdict, deque
from joblib import load
import numpy as np
import os

try:
    import tensorflow as tf  # only needed for Keras path
except Exception:
    tf = None

# --------- paths (override with env if you like) ----------
MODEL_PKL    = os.getenv("MODEL_PKL",    "models/LR/model.pkl")       # LR bundle path
MANIFEST_PKL = os.getenv("MANIFEST_PKL", "models/GRU/manifest.pkl")   # Keras manifest path

app = Flask(__name__)

# --------- helpers ----------
def check_alert(v: float, rule) -> bool:
    op  = rule.get("op", ">=")
    thr = float(rule.get("threshold", 150.0))
    if op == ">=": return v >= thr
    if op == "<=": return v <= thr
    if op == ">":  return v >  thr
    if op == "<":  return v <  thr
    return False

def load_lr_bundle(path):
    obj = load(path)
    if isinstance(obj, dict) and "model" in obj and "meta" in obj:
        return obj
    return None

def load_keras_manifest(path):
    man = load(path)
    if isinstance(man, dict) and "models" in man and "feature_cols" in man:
        return man
    return None

# --------- try LR first, then Keras manifest ----------
lr_bundle = None
keras_manifest = None

try:
    lr_bundle = load_lr_bundle(MODEL_PKL)
except Exception:
    lr_bundle = None

if lr_bundle is None:
    try:
        keras_manifest = load_keras_manifest(MANIFEST_PKL)
    except Exception:
        keras_manifest = None

if (lr_bundle is None) and (keras_manifest is None):
    raise RuntimeError(
        "No usable model artifact found. "
        f"Tried LR bundle at '{MODEL_PKL}' and Keras manifest at '{MANIFEST_PKL}'."
    )

# --------- build runtime from whichever we loaded ----------
buffers = None

if lr_bundle is not None:
    # ===== Linear Regression path =====
    model = lr_bundle["model"]
    meta  = lr_bundle["meta"]

    LAG      = int(meta.get("lag", 20))
    STEPS    = int(meta.get("steps", 3))
    FEATURES = list(meta.get("features", ["disch1","disch2","disch3"]))
    ALERT    = meta.get("alert", {"op": ">=", "threshold": 150.0})

    # keep per-sensor buffers (even if LR) for consistency
    buffers = defaultdict(lambda: deque(maxlen=LAG))

    @app.route("/score", methods=["POST"])
    def score_lr():
        d = request.get_json(force=True)
        sid = d.get("sensor_id", "unknown")

        row = [float(d[c]) for c in FEATURES]
        buffers[sid].append(row)

        if len(buffers[sid]) < LAG:
            return jsonify({"ready": False, "need": LAG - len(buffers[sid])})

        window = np.array(buffers[sid], dtype=np.float32) 
        X = window.reshape(1, -1)                             
        preds = model.predict(X).ravel().tolist()             
        return jsonify({
            "ready": True,
            "sensor_id": sid,
            "pred": preds,
            "alert": check_alert(preds[0], ALERT),
            "alert_rule": ALERT,
            "engine": "LR"
        })

    @app.route("/health", methods=["GET"])
    def health_lr():
        return jsonify({"ok": True, "engine": "LR", "lag": LAG, "features": FEATURES})

else:
    if tf is None:
        raise RuntimeError("TensorFlow is required to load a Keras model from manifest.")

    LAG      = int(keras_manifest["lag"])
    STEPS    = int(keras_manifest["steps"])
    FEATURES = list(keras_manifest["feature_cols"])
    ALERT    = keras_manifest.get("alert", {"op": ">=", "threshold": 150.0})
    MODEL_INFO = keras_manifest["models"]["keras_seq"]

    model = tf.keras.models.load_model(MODEL_INFO["path"])

    buffers = defaultdict(lambda: deque(maxlen=LAG))

    @app.route("/score", methods=["POST"])
    def score_keras():
        d = request.get_json(force=True)
        sid = d.get("sensor_id", "unknown")

        row = [float(d[c]) for c in FEATURES]
        buffers[sid].append(row)

        if len(buffers[sid]) < LAG:
            return jsonify({"ready": False, "need": LAG - len(buffers[sid])})

        window = np.array(buffers[sid], dtype=np.float32)      # (LAG, F)
        preds  = model.predict(window[None, ...], verbose=0).ravel().tolist()
        return jsonify({
            "ready": True,
            "sensor_id": sid,
            "pred": preds,
            "alert": check_alert(preds[0], ALERT),
            "alert_rule": ALERT,
            "engine": "Keras"
        })

    @app.route("/health", methods=["GET"])
    def health_keras():
        return jsonify({"ok": True, "engine": "Keras", "lag": LAG, "features": FEATURES})

if __name__ == "__main__":
    app.run(port=5001)
