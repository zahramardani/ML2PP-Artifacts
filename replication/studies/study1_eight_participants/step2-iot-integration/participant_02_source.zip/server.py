# server.py
from flask import Flask, request, jsonify
import requests

app = Flask(__name__)

ANALYTICS_URL = "http://127.0.0.1:5001/score"
TIMEOUT = 5

@app.route("/ingest", methods=["POST"])
def ingest():
    payload = request.get_json(force=True)
    alerts = 0

    for r in payload.get("readings", []):
        try:
            out = requests.post(ANALYTICS_URL, json=r, timeout=TIMEOUT).json()
            if out.get("alert"):
                alerts += 1
                print("ALERT: Flood risk!", out)
        except Exception as e:
            print("Forward error:", e)

    return jsonify({"ok": True, "alerts": alerts})

if __name__ == "__main__":
    app.run(port=5000)
